//#include<iostream>
//using namespace std;
//
//class ICallBackDelegate {
//public:
//	virtual void OnSeatBeltNotInstall()=0;
//};
//
//class SafeCheck {
//private:
//	ICallBackDelegate *_owner;
//	bool CheckSeatBelt() { 
//		cout << "Is seatBelt OK?: ";
//		int res;
//		cin >> res;
//		if (res == 0)return false;
//		return true;
//	}
//public:
//	void Check() {
//		if (!CheckSeatBelt())//check first seat belt is installed or not?
//			if (_owner)//push the call back
//				_owner->OnSeatBeltNotInstall();
//	}
//	void SetOwnerDelegate(ICallBackDelegate *owner) {
//		_owner = owner;
//	}
//};
//
//class Car : public ICallBackDelegate {
//private:
//	bool _isEnableToStart;
//	SafeCheck *_safeChecker;
//protected:
//	virtual void OnSeatBeltNotInstall() {
//		_isEnableToStart = false;
//	}
//public:
//	Car() {
//		_safeChecker = new SafeCheck();
//		_safeChecker->SetOwnerDelegate(this);
//		_isEnableToStart = true;
//	}
//	void Start() {
//		cout << "Check safe condition before to start the car...." << endl;
//		if (_safeChecker != NULL)
//			_safeChecker->Check();
//		if (_isEnableToStart)
//			cout << "Ready to go!" << endl;
//		else
//			cout << "Please check safe condition first." << endl;
//	}
//};
//
//int main() {
//	Car c1, c2;
//	c1.Start();
//
//	c2.Start();
//	return 0;
//}