#include "Map2D.h"
#include "Point2D.h"

int main() {
	Map2D myMap;
	myMap.DisplayMap();
	
	Point2D p1(5, 5, 'O');
	p1.Display();


	return 0;
}