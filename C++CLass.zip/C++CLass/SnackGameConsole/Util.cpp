#pragma once
#include "Util.h"
#include <time.h>

void CursorGotoXY(int x, int y) {
	COORD pos = { x,y };
	HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(output, pos);
}

int GetRandomNumber(int vlMax) {
	srand(time(NULL));
	int r = rand();
	return r % vlMax;
}