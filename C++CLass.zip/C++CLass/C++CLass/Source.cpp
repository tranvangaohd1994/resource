//#include<iostream>
//using namespace std;
//
//
//class Base {
//private:
//	int priv = 1;
//protected:
//	int prot = 2;
//public:
//	int pub = 3;
//	//function to access private member
//	int getPriv() { return priv; }
//};
//
//class PublicDerive : public Base {
//public:
//	int getProt() { return prot; }
//};
//
//class ProtectedDerive : protected Base {
//public:
//	int ProGetPub() { return pub; }
//	int ProtGetProt() { return prot; }
//};
//
//class PrivateDerive : private Base {
//public:
//	//function to access protected member from Base, because this is private tin this class
//	int getProt() { return prot; } //
//	int getPub() { return pub; }
//};
//
//
//int main() {
//	Base base, *pBase;
//	pBase = &base;
//
//	ProtectedDerive protBase;
//	protBase.ProGetPub();
//	protBase.ProtGetProt();
//
//	base.getPriv(); base.pub;
//	cout << ((PublicDerive*)pBase)->getProt() << endl;
//
//	PublicDerive cPub;
//	cPub.getPriv(); cPub.getProt(); cPub.pub;
//
//
//
//	return 0;
//}