from tqdm import tqdm
import numpy as np
import pandas as pd

def FilterUE(df, number_station, method='CellId'):
    """df: raw data
    number_station: number of station to filter
    method: 'CellId' or anything else
            CellId: filter by number of CellId
            else: filter by number of CellId_div_256"""

    df = df.dropna(subset=['UE', 'CellId'])
    df['CellID_div_256'] = np.round(df['CellId'] / 256).astype(int)

    list_UE = []
    for UE in tqdm(df['UE'].unique()):
        df_UE = df.loc[df['UE'] == UE].copy()
        df_UE = df_UE.sort_values(by=['Time'])
        if method == 'CellId':
            if len(df_UE['CellId'].unique()) >= number_station:
                list_UE.append(UE)
        else:
            if len(df_UE['CellID_div_256'].unique()) >= number_station:
                list_UE.append(UE)

    """
    return: list of UE and dataframe of UE 
    """

    return list_UE, df.loc[df['UE'].isin(list_UE)].reset_index(drop=True).drop(columns=['CellID_div_256'])