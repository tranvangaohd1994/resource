#pragma once
#include<Windows.h>

#define WINDOW_WIDTH 100
#define WINDOW_HEIGHT 30

void CursorGotoXY(int x, int y);
int  GetRandomNumber(int vlMax);
