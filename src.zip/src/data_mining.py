#https://tiensu.github.io/blog/05_comprehensive_guide_to_ensemble_model_2/
#from evidently.test_preset import DataDriftTestPreset
#from evidently.test_suite import TestSuite
import pandas as pd
from problem_config import ProblemConfig, get_prob_config
from sklearn import preprocessing
from matplotlib import pyplot as plt
#from pandas_profiling import ProfileReport
from typing import Tuple
from sklearn.base import BaseEstimator, TransformerMixin
import mlflow
import numpy as np


def predictCaptureData():
    model_uri = 'mlartifacts\\713059362068149586\\e0c34374d71449f7adb85e62a104be8b\\artifacts\\model'
    model = mlflow.sklearn.load_model(model_uri)
    
    x_capture_full = pd.read_csv('data/captured_data/phase-1/prob-1/processed/captured_x.csv')
    x_capture_drop = x_capture_full.drop(columns=['is_drift','batch_id'])
    y_drift = x_capture_full['is_drift']
    #print(x_capture_full.describe())
    print('-----len:', len(x_capture_drop))
    
    probas = model.predict_proba(x_capture_drop)
    df = pd.DataFrame(np.array(probas), columns = ['label0','label1'])
    arr = np.arange(0.0, 1.0, 0.1)
    for i in arr:
        print('num sample in range : ', len(df[ (df['label0'] >= i) & (df['label0'] < (i+0.1)) ]))
    
    pro_drift = pd.DataFrame(np.array(probas[y_drift == 1]), columns = ['label0','label1'])
    print(pro_drift.describe())
    for i in arr:
        print('num label_0 in range : ', len(pro_drift[ (pro_drift['label0'] >= i) & (pro_drift['label0'] < (i+0.1)) ]))
    
    print('number is drift' , len(y_drift[(y_drift == 1)]))

    while False:
        id = input('num of sample:')
        predic = model.predict(x_capture_drop.iloc[[id]])
        proba = model.predict_proba(x_capture_drop.iloc[[id]])
        print(predic, proba)


def data_mining(prob_config: ProblemConfig):
    
    # train_x = pd.read_parquet(prob_config.train_x_path)
    # clipped_feature3 = BoxplotOutlierClipper().fit_transform(train_x["feature3"])
    # fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(15, 5))
    # clipped_feature3.hist(bins=50, ax=axes[0])
    # train_x["feature3"].hist(bins=50, ax=axes[1])
    # clipped_feature3.to_frame().boxplot(ax=axes[2], vert=False)
    # plt.show()
    # return

    #training_data = pd.read_parquet(prob_config.raw_data_path)
    # training_data = pd.read_csv(str(prob_config.captured_x_path).split('.')[0]+'.csv') 
    # profile = ProfileReport( training_data, title="Pandas Profiling Report for Titanic train dataset")
    # profile.to_file(str(prob_config.captured_x_path).split('.')[0]+"_profiling.html")
    # return 

    #train_x = pd.read_parquet(prob_config.train_x_path)

    test_x = pd.read_parquet(prob_config.captured_x_path)
    test_x.to_csv(str(prob_config.captured_x_path).split('.')[0]+'.csv', index=False)

    #test_x.hist(bins=50, figsize=(20, 15))
    #plt.show()

    #preprocess_data(train_x, prob_config)
    #des = pd.DataFrame(train_x.describe())
    #des.to_csv(str(prob_config.captured_x_path).split('.')[0]+'_describe.csv', index=False)
    #print('---------', train_x['feature1'].value_counts())
    #print('---------', train_x['feature2'].value_counts())
    return

    train_y = pd.read_parquet(prob_config.train_y_path)
    test_x = pd.read_parquet(prob_config.test_x_path)
    test_y = pd.read_parquet(prob_config.test_y_path)
    min_max_scaler = preprocessing.MinMaxScaler()

    columns = ['feature3','feature4', 'feature5', 'feature6', 'feature7', 'feature8', 
               'feature9', 'feature10', 'feature14', 'feature15', 'feature16']
    df1 = pd.DataFrame(train_x, columns=columns)
    print(df1['feature16'].isnull().sum())
    #print(df1.describe()) 
    # df.fillna(df.mean())

    #df1 =  pd.DataFrame( min_max_scaler.fit_transform(train_x['feature3']))
    print(train_x.describe()) 
    train_x['feature3'] =  min_max_scaler.fit_transform(pd.DataFrame(train_x['feature3']))
    print(train_x.describe()) 
    #print(df1.isnull().sum())
    #print(df1.describe())

    return


    a = training_data['feature1'].unique()
    print(len(a), ' : ', *a,  sep=", ")
    print('-'*10)

    b = training_data['feature2'].unique()
    print(len(b), ' : ', *b,  sep=", ")
    print('-'*10)
    
    print(training_data.describe())
    print('-'*10)

    print(train_x.describe())
    print('-'*10)
    print(train_y.sum(axis=0), train_y.isin([0]).sum())
    print('-'*10)
    print(test_x.describe())
    print('-'*10)
    print(test_y.sum(axis=0), test_y.isin([0]).sum())

def preprocess_data(df : pd.DataFrame, prob_config:ProblemConfig):
    '''preprocess data - minmax_scaler, fill_nan_value'''
    #fill nan value by 0
    df.fillna(0)
    #min_max_scaler - nomalize data
    min_max_scaler = preprocessing.MinMaxScaler()
    for col in prob_config.numerical_cols:
        df[col] =  min_max_scaler.fit_transform(pd.DataFrame(df[col]))

#------https://machinelearningcoban.com/tabml_book/ch_data_processing/process_outliers.html

def find_boxplot_boundaries(col: pd.Series, whisker_coeff: float = 1.5) -> Tuple[float, float]:
    """Findx minimum and maximum in boxplot.
    Args:
        col: a pandas serires of input.
        whisker_coeff: whisker coefficient in box plot
    """
    Q1 = col.quantile(0.25)
    Q3 = col.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - whisker_coeff * IQR
    upper = Q3 + whisker_coeff * IQR
    return lower, upper

class BoxplotOutlierClipper(BaseEstimator, TransformerMixin):
    def __init__(self, whisker_coeff: float = 1.5):
        self.whisker = whisker_coeff
        self.lower = None
        self.upper = None

    def fit(self, X: pd.Series):
        self.lower, self.upper = find_boxplot_boundaries(X, self.whisker)
        return self

    def transform(self, X):
        return X.clip(self.lower, self.upper)

def clip_data(train_x:pd.DataFrame, test_x:pd.DataFrame, col_clip:list):
    for col in col_clip:
        tranform = BoxplotOutlierClipper()
        tranform.fit(train_x[col])
        train_x[col] = tranform.transform(train_x[col])
        test_x[col] = tranform.transform(test_x[col])

    return train_x, test_x
#--------------------------------------------------------------------------------------------
if __name__ == '__main__':
    #predictCaptureData()
    prob_config = get_prob_config('phase-1', 'prob-2')
    data_mining(prob_config)
    