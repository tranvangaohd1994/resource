#include "Map2D.h"
#include "Util.h"
#include "Point2D.h"

void Map2D::InitMap() {
	for (int y = 0; y < WINDOW_HEIGHT; y++) {
		for (int x = 0; x < WINDOW_WIDTH; x++) {
			if (y == 0 || x == 0 || y == WINDOW_HEIGHT - 1 || x == WINDOW_WIDTH - 1)
				_map[y][x] = Point2D(x, y, '#');
			else
				_map[y][x] = Point2D(x, y, ' ');
		}
	}
}

Map2D::Map2D(){
	InitMap();
}

Map2D::~Map2D(){
}

void Map2D::DisplayMap() {
	for (int y = 0; y < WINDOW_HEIGHT; y++)
		for (int x = 0; x < WINDOW_WIDTH; x++)
			_map[y][x].Display();
}