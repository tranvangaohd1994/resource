//#include<iostream>
//#include <string>
//using namespace std;
//
//class Machine{
//public:
//	virtual void PressBreaker() = 0;
//};
//
//
//class Car : public Machine{
//public:
//	void PressBreaker() {}
//	int _size;
//	Car() {
//		_size = 10;
//	}
//	void setSize(int size) {
//		_size = size;
//	}
//	virtual void TurnOnHorn() {
//		cout << "Car: Beep Beep." << endl;
//	}
//	void HornNonVirtual() {
//		cout << "Car: nonVirtual" << endl;
//	}
//	bool operator <(Car &c) {
//		return this->_size < c._size;
//	}
//};
//
//class PoliceCar : public Car {
//public: 
//	int x = 10, y, z, k;
//	PoliceCar() {
//		_size = 20;
//	}
//	void HornNonVirtual() {
//		cout << "PoliceCar: nonVirtual" << endl;
//	}
//
//	virtual void TurnOnHorn()
//	{ 
//		cout << "Police: To Te To Te." << endl;
//	}
//	void TurnOnHorn(int mode) {
//		if(mode == 0) cout << "Police: Beep Beep." << x << endl;
//		else cout << "Police: To Te To Te." << x << endl;
//	}
//	void TurnOnHorn(string s) {
//		cout << "Police:" << s << x << endl;
//	}
//};
//
//int main() {
//	Car c, c11, c12;
//	PoliceCar pc, *p;
//	
//	c11.setSize(10);
//	c12.setSize(20);
//
//	if (c11 < c12) {
//		cout << c11._size << " " << c12._size << endl;
//	}
//	
//	p = (PoliceCar*)&c;
//	p->TurnOnHorn();
//	p->HornNonVirtual();
//	p->TurnOnHorn("pipi");
//	p->TurnOnHorn(0);
//
//	Car *c2 = &pc;
//	c2->TurnOnHorn();
//	c2->HornNonVirtual();
//	
//	((PoliceCar*)c2)->TurnOnHorn("pipi");
//	((PoliceCar*)c2)->TurnOnHorn(0);
//
//
//	return 0;
//}