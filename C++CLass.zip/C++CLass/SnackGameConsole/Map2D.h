#include "Point2D.h"
#include "Util.h"

class Map2D {
private:
	void InitMap();
	Point2D _map[WINDOW_HEIGHT][WINDOW_WIDTH];
public:
	Map2D();
	~Map2D();
	void DisplayMap();
};