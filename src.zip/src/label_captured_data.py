import argparse
import logging
import numpy as np
import pandas as pd
from sklearn.cluster import MiniBatchKMeans
from problem_config import ProblemConfig, ProblemConst, get_prob_config
import pickle


def label_captured_data(prob_config: ProblemConfig):
    train_x = pd.read_parquet(prob_config.train_x_path).to_numpy()
    train_y = pd.read_parquet(prob_config.train_y_path).to_numpy()
    ml_type = prob_config.ml_type

    logging.info("Load captured data")
    captured_x = pd.DataFrame()
    for file_path in prob_config.captured_data_dir.glob("*.parquet"):
        captured_data = pd.read_parquet(file_path)
        captured_x = pd.concat([captured_x, captured_data])

    captured_x.to_csv(str(prob_config.captured_x_path).split('.')[0]+'_raw.csv', index=False)
    print(str(prob_config.captured_x_path).split('.')[0]+'_raw.csv')
    exit()
    #print(captured_x.describe())
    feature_df_drop = captured_x.drop(columns=['is_drift','batch_id'])

    np_captured_x = feature_df_drop.to_numpy()
    n_captured = len(np_captured_x)
    n_samples = len(train_x) + n_captured
    logging.info(f"Loaded {n_captured} captured samples, {n_samples} train + captured")

    logging.info("Initialize and fit the clustering model")
    n_cluster = int(n_samples / 10) * len(np.unique(train_y))
    kmeans_model = MiniBatchKMeans(
        n_clusters=n_cluster, random_state=prob_config.random_state
    ).fit(train_x)

    logging.info("Predict the cluster assignments for the new data")
    kmeans_clusters = kmeans_model.predict(np_captured_x)

    logging.info(
        "Assign new labels to the new data based on the labels of the original data in each cluster"
    )
    new_labels = []
    for i in range(n_cluster):
        mask = kmeans_model.labels_ == i  # mask for data points in cluster i
        cluster_labels = train_y[mask]  # labels of data points in cluster i
        if len(cluster_labels) == 0:
            # If no data points in the cluster, assign a default label (e.g., 0)
            new_labels.append(0)
        else:
            # For a linear regression problem, use the mean of the labels as the new label
            # For a logistic regression problem, use the mode of the labels as the new label
            if ml_type == "regression":
                new_labels.append(np.mean(cluster_labels.flatten()))
            else:
                new_labels.append(
                    np.bincount(cluster_labels.flatten().astype(int)).argmax()
                )

    approx_label = [new_labels[c] for c in kmeans_clusters]
    approx_label_df = pd.DataFrame(approx_label, columns=[prob_config.target_col])

    captured_x.to_parquet(prob_config.captured_x_path, index=False)
    #captured_x.to_csv(str(prob_config.train_x_path).split('.')[0]+'.csv', index=False)
    approx_label_df.to_parquet(prob_config.uncertain_y_path, index=False)

    #save model kmean-sklearn
    with open(str(prob_config.train_x_path).split('.')[0] + "_kmean_model.pkl", "wb") as f:
        pickle.dump(kmeans_model, f)
    #load model sklearn
    #with open("model.pkl", "rb") as f:
    #    model = pickle.load(f)



if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase-id", type=str, default=ProblemConst.PHASE1)
    parser.add_argument("--prob-id", type=str, default=ProblemConst.PROB1)
    args = parser.parse_args()

    prob_config = get_prob_config(args.phase_id, args.prob_id)
    label_captured_data(prob_config)
